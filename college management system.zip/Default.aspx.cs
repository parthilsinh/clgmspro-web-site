﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class Admin_login : System.Web.UI.Page
{
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        mycon();

        if (DropDownList1.SelectedValue == "Student")
        {
            cmd = new MySqlCommand("select * from student_master where username=@username and password=@password", con);
            cmd.Parameters.AddWithValue("@username", txt_enroll.Text);
            cmd.Parameters.AddWithValue("@password", txt_password.Text);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if(ds.Tables[0].Rows[0]["status"].ToString() == "1")
                {
                    Session["studentId"] = ds.Tables[0].Rows[0]["s_id"].ToString();
                    Session["studentBranch"] = ds.Tables[0].Rows[0]["branch"].ToString();
                    Session["studentSem"] = ds.Tables[0].Rows[0]["sem"].ToString();
                    Session["studentDiv"] = ds.Tables[0].Rows[0]["division"].ToString();
                    Session["studentEnroll"] = ds.Tables[0].Rows[0]["enroll"].ToString();
                    Session["studentName"] = ds.Tables[0].Rows[0]["f_name"].ToString() + " " + ds.Tables[0].Rows[0]["l_name"].ToString();
                    Response.Redirect("dashboard/student-dashboard.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Your account is not verified');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid username of password');</script>");
            }


        }
        else if(DropDownList1.SelectedValue == "Teacher")
        {
            cmd = new MySqlCommand("select * from teacher_master where username=@username and password=@password", con);
            cmd.Parameters.AddWithValue("@username", txt_enroll.Text);
            cmd.Parameters.AddWithValue("@password", txt_password.Text);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["status"].ToString() == "1")
                {
                    Session["teacherId"] = ds.Tables[0].Rows[0]["t_id"].ToString();
                    Session["teacherName"] = ds.Tables[0].Rows[0]["f_name"].ToString() + " " + ds.Tables[0].Rows[0]["l_name"].ToString();
                    Session["teacherBranch"] = ds.Tables[0].Rows[0]["branch"].ToString();
                    Response.Redirect("dashboard/teacher-dashboard.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Your account is not verified');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid username of password');</script>");
            }

        }
        else if(DropDownList1.SelectedValue == "Admin")
        {
            cmd = new MySqlCommand("select * from admin_master where admin_username=@username and admin_password=@password", con);
            cmd.Parameters.AddWithValue("@username", txt_enroll.Text);
            cmd.Parameters.AddWithValue("@password", txt_password.Text);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["adminId"] = ds.Tables[0].Rows[0]["admin_id"].ToString();
                Session["adminName"] = ds.Tables[0].Rows[0]["admin_name"].ToString();
                Response.Redirect("dashboard/admin_dashboard.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid username of password');</script>");
            }

        }
        con.Close();
    }
}