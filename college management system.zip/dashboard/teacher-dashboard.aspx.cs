﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class dashboard_teacher_dashboard : System.Web.UI.Page
{
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    int getAssignment()
    {
        mycon();
        cmd = new MySqlCommand("select * from assignment_master where t_id=@tid", con);
        cmd.Parameters.AddWithValue("@tid", Convert.ToInt32(Session["teacherId"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _assignment_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _assignment_count;
    }

    int getAttendance()
    {
        mycon();
        cmd = new MySqlCommand("select * from attendence_master am left join student_master sm on am.s_id=sm.s_id where sm.branch=@branch and (am.att_status=@status and am.att_date=@date)", con);
        cmd.Parameters.AddWithValue("@branch", Convert.ToString(Session["teacherBranch"]));
        cmd.Parameters.AddWithValue("@status", "Present");
        cmd.Parameters.AddWithValue("@date", System.DateTime.Today.ToString("dd-MM-yyyy"));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _attendence_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _attendence_count;
    }

    int getNotification()
    {
        mycon();
        cmd = new MySqlCommand("select * from announcement_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _notification_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _notification_count;
    }

    int getMessage()
    {
        mycon();
        cmd = new MySqlCommand("select * from message_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _message_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _message_count;
    }

    void getTeacherProfile()
    {
        cmd = new MySqlCommand("select * from teacher_master where t_id=@id", con);
        cmd.Parameters.AddWithValue("@id", Convert.ToString(Session["teacherId"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rpt_pro.DataSource = ds;
            rpt_pro.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            mycon();
            getTeacherProfile();
            cmd = new MySqlCommand("select * from announcement_master where an_for=@for1 or an_for=@for2", con);
            cmd.Parameters.AddWithValue("@for1", "All");
            cmd.Parameters.AddWithValue("@for2", "Teacher");
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rpt_an.DataSource = ds;
                rpt_an.DataBind();
            }
            con.Close();

            count_assignment.InnerText = Convert.ToString(getAssignment());
            count_attendance.InnerText = Convert.ToString(getAttendance());
            count_message.InnerText = Convert.ToString(getMessage());
            count_notification.InnerText = Convert.ToString(getNotification());


        }
    }
}