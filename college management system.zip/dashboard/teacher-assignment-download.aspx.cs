﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class dashboard_teacher_assignment_download : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    void getAssign()
    {
        mycon();
        cmd = new MySqlCommand("select * from assignment_upload_master aum left join assignment_master am on aum.ans_id=am.asn_id where aum.t_id=@tid", con);
        cmd.Parameters.AddWithValue("@tid", Convert.ToString(Session["teacherId"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rpt_assign.DataSource = ds;
            rpt_assign.DataBind();
        }

        con.Close();
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getAssign();
        }
    }
}