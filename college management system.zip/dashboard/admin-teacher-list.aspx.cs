﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;
public partial class dashboard_admin_teacher_list : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mycon();
            cmd = new MySqlCommand("select * from teacher_master", con);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Repeater1.DataSource = ds;
                Repeater1.DataBind();
            }
            con.Close();
        }
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        RepeaterItem item = e.Item;
        //(item.FindControl("drop_v") as DropDownList).SelectedValue = (item.FindControl("HiddenField1") as HiddenField).Value;
        HiddenField hf1 = (item.FindControl("HiddenField1") as HiddenField);
        Button b1 = (item.FindControl("Button1") as Button); 
        if (hf1.Value == "1")
        {
            b1.Text = "Deactivate User";
        }
        else
        {
            b1.Text = "Activate User";
        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
        int _teacher_id = Convert.ToInt32(commandArgs[0]);
        int _status = Convert.ToInt32(commandArgs[1]);
        if(_status == 1)
        {
            _status = 0;
        }
        else
        {
            _status = 1;
        }
        mycon();
        cmd = new MySqlCommand("update teacher_master set status=@status where t_id=@id", con);
        cmd.Parameters.AddWithValue("@status", _status);
        cmd.Parameters.AddWithValue("@id", _teacher_id);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect(Request.RawUrl);
    }
}