﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class dashboard_teacher_view_student_attendence : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_select_Click(object sender, EventArgs e)
    {
        mycon();
        cmd = new MySqlCommand("select * from student_master sm right join attendence_master am on sm.s_id=am.s_id where sm.branch=@branch and (sm.sem=@sem and sm.division=@division)", con);
        cmd.Parameters.AddWithValue("@branch", drop_branch.SelectedValue);
        cmd.Parameters.AddWithValue("@sem", drop_sem.SelectedValue);
        cmd.Parameters.AddWithValue("@division", drop_div.SelectedValue);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rpt_att.DataSource = ds;
            rpt_att.DataBind();
        }
        else
        {
            //Response.Write(Request.RawUrl);
            rpt_att.DataSource = ds;
            rpt_att.DataBind();
        }
        con.Close();
    }
}