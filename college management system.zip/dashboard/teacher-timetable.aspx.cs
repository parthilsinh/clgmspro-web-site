﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class dashboard_teacher_timetable : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    static Boolean _is_exist_timetable;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    DataSet isDataAvail()
    {
        mycon();
        cmd = new MySqlCommand("select * from timetable_master where tt_branch=@branch", con);
        cmd.Parameters.AddWithValue("@branch", Convert.ToString(Session["teacherBranch"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            timetable_head.InnerText = "TIMETABLE FOR " + Convert.ToString(Session["teacherBranch"]).ToUpper();
            DataSet _ds = isDataAvail();
            if(_ds.Tables[0].Rows.Count>0)
            {
                // First lecture
                TextBox1.Text = _ds.Tables[0].Rows[0]["a_time"].ToString();
                TextBox2.Text = _ds.Tables[0].Rows[0]["a_monday"].ToString();
                TextBox3.Text = _ds.Tables[0].Rows[0]["a_tuesday"].ToString();
                TextBox4.Text = _ds.Tables[0].Rows[0]["a_wednesday"].ToString();
                TextBox5.Text = _ds.Tables[0].Rows[0]["a_thursday"].ToString();
                TextBox6.Text = _ds.Tables[0].Rows[0]["a_friday"].ToString();
                TextBox7.Text = _ds.Tables[0].Rows[0]["a_saturday"].ToString();
                // Second lecture
                TextBox8.Text = _ds.Tables[0].Rows[0]["b_time"].ToString();
                TextBox9.Text = _ds.Tables[0].Rows[0]["b_monday"].ToString();
                TextBox10.Text = _ds.Tables[0].Rows[0]["b_tuesday"].ToString();
                TextBox11.Text = _ds.Tables[0].Rows[0]["b_wednesday"].ToString();
                TextBox12.Text = _ds.Tables[0].Rows[0]["b_thursday"].ToString();
                TextBox13.Text = _ds.Tables[0].Rows[0]["b_friday"].ToString();
                TextBox14.Text = _ds.Tables[0].Rows[0]["b_saturday"].ToString();
                // Third lecture
                TextBox15.Text = _ds.Tables[0].Rows[0]["c_time"].ToString();
                TextBox16.Text = _ds.Tables[0].Rows[0]["c_monday"].ToString();
                TextBox17.Text = _ds.Tables[0].Rows[0]["c_tuesday"].ToString();
                TextBox18.Text = _ds.Tables[0].Rows[0]["c_wednesday"].ToString();
                TextBox19.Text = _ds.Tables[0].Rows[0]["c_thursday"].ToString();
                TextBox20.Text = _ds.Tables[0].Rows[0]["c_friday"].ToString();
                TextBox21.Text = _ds.Tables[0].Rows[0]["c_saturday"].ToString();
                // Fourth lecture
                TextBox22.Text = _ds.Tables[0].Rows[0]["d_time"].ToString();
                TextBox23.Text = _ds.Tables[0].Rows[0]["d_monday"].ToString();
                TextBox24.Text = _ds.Tables[0].Rows[0]["d_tuesday"].ToString();
                TextBox25.Text = _ds.Tables[0].Rows[0]["d_wednesday"].ToString();
                TextBox26.Text = _ds.Tables[0].Rows[0]["d_thursday"].ToString();
                TextBox27.Text = _ds.Tables[0].Rows[0]["d_friday"].ToString();
                TextBox28.Text = _ds.Tables[0].Rows[0]["d_saturday"].ToString();
                // Fifth lecture
                TextBox29.Text = _ds.Tables[0].Rows[0]["e_time"].ToString();
                TextBox30.Text = _ds.Tables[0].Rows[0]["e_monday"].ToString();
                TextBox31.Text = _ds.Tables[0].Rows[0]["e_tuesday"].ToString();
                TextBox32.Text = _ds.Tables[0].Rows[0]["e_wednesday"].ToString();
                TextBox33.Text = _ds.Tables[0].Rows[0]["e_thursday"].ToString();
                TextBox34.Text = _ds.Tables[0].Rows[0]["e_friday"].ToString();
                TextBox35.Text = _ds.Tables[0].Rows[0]["e_saturday"].ToString();
                _is_exist_timetable = true;
            }
            else
            {
                _is_exist_timetable = false;
            }
        }
    }

    protected void btn_save_Click(object sender, EventArgs e)
    {
        mycon();
        if(_is_exist_timetable == true)
        {
            cmd = new MySqlCommand("update timetable_master set a_time=@a_time, a_monday=@a_monday, a_tuesday=@a_tuesday, a_wednesday=@a_wednesday, a_thursday=@a_thursday, a_friday=@a_friday, a_saturday=@a_saturday, b_time=@b_time, b_monday=@b_monday, b_tuesday=@b_tuesday, b_wednesday=@b_wednesday, b_thursday=@b_thursday, b_friday=@b_friday, b_saturday=@b_saturday, c_time=@c_time, c_monday=@c_monday, c_tuesday=@c_tuesday, c_wednesday=@c_wednesday, c_thursday=@c_thursday, c_friday=@c_friday, c_saturday=@c_saturday, d_time=@d_time, d_monday=@d_monday, d_tuesday=@d_tuesday, d_wednesday=@d_wednesday, d_thursday=@d_thursday, d_friday=@d_friday, d_saturday=@d_saturday, e_time=@e_time, e_monday=@e_monday, e_tuesday=@e_tuesday, e_wednesday=@e_wednesday, e_thursday=@e_thursday, e_friday=@e_friday, e_saturday=@e_saturday where tt_branch=@tt_branch", con);
            cmd.Parameters.AddWithValue("@tt_branch", Convert.ToString(Session["teacherBranch"]));
            cmd.Parameters.AddWithValue("@a_time", TextBox1.Text);
            cmd.Parameters.AddWithValue("@a_monday", TextBox2.Text);
            cmd.Parameters.AddWithValue("@a_tuesday", TextBox3.Text);
            cmd.Parameters.AddWithValue("@a_wednesday", TextBox4.Text);
            cmd.Parameters.AddWithValue("@a_thursday", TextBox5.Text);
            cmd.Parameters.AddWithValue("@a_friday", TextBox6.Text);
            cmd.Parameters.AddWithValue("@a_saturday", TextBox7.Text);
            cmd.Parameters.AddWithValue("@b_time", TextBox8.Text);
            cmd.Parameters.AddWithValue("@b_monday", TextBox9.Text);
            cmd.Parameters.AddWithValue("@b_tuesday", TextBox10.Text);
            cmd.Parameters.AddWithValue("@b_wednesday", TextBox11.Text);
            cmd.Parameters.AddWithValue("@b_thursday", TextBox12.Text);
            cmd.Parameters.AddWithValue("@b_friday", TextBox13.Text);
            cmd.Parameters.AddWithValue("@b_saturday", TextBox14.Text);
            cmd.Parameters.AddWithValue("@c_time", TextBox15.Text);
            cmd.Parameters.AddWithValue("@c_monday", TextBox16.Text);
            cmd.Parameters.AddWithValue("@c_tuesday", TextBox17.Text);
            cmd.Parameters.AddWithValue("@c_wednesday", TextBox18.Text);
            cmd.Parameters.AddWithValue("@c_thursday", TextBox19.Text);
            cmd.Parameters.AddWithValue("@c_friday", TextBox20.Text);
            cmd.Parameters.AddWithValue("@c_saturday", TextBox21.Text);
            cmd.Parameters.AddWithValue("@d_time", TextBox22.Text);
            cmd.Parameters.AddWithValue("@d_monday", TextBox23.Text);
            cmd.Parameters.AddWithValue("@d_tuesday", TextBox24.Text);
            cmd.Parameters.AddWithValue("@d_wednesday", TextBox25.Text);
            cmd.Parameters.AddWithValue("@d_thursday", TextBox26.Text);
            cmd.Parameters.AddWithValue("@d_friday", TextBox27.Text);
            cmd.Parameters.AddWithValue("@d_saturday", TextBox28.Text);
            cmd.Parameters.AddWithValue("@e_time", TextBox29.Text);
            cmd.Parameters.AddWithValue("@e_monday", TextBox30.Text);
            cmd.Parameters.AddWithValue("@e_tuesday", TextBox31.Text);
            cmd.Parameters.AddWithValue("@e_wednesday", TextBox32.Text);
            cmd.Parameters.AddWithValue("@e_thursday", TextBox33.Text);
            cmd.Parameters.AddWithValue("@e_friday", TextBox34.Text);
            cmd.Parameters.AddWithValue("@e_saturday", TextBox35.Text);
            cmd.ExecuteNonQuery();
        }
        else
        {
            cmd = new MySqlCommand("INSERT INTO timetable_master values(NULL, @tt_branch, @a_time, @a_monday, @a_tuesday, @a_wednesday, @a_thursday, @a_friday, @a_saturday, @b_time, @b_monday, @b_tuesday, @b_wednesday, @b_thursday, @b_friday, @b_saturday, @c_time, @c_monday, @c_tuesday, @c_wednesday, @c_thursday, @c_friday, @c_saturday, @d_time, @d_monday, @d_tuesday, @d_wednesday, @d_thursday, @d_friday, @d_saturday, @e_time, @e_monday, @e_tuesday, @e_wednesday, @e_thursday, @e_friday, @e_saturday)", con);
            cmd.Parameters.AddWithValue("@tt_branch",Convert.ToString(Session["teacherBranch"]));
            cmd.Parameters.AddWithValue("@a_time", TextBox1.Text);
            cmd.Parameters.AddWithValue("@a_monday", TextBox2.Text);
            cmd.Parameters.AddWithValue("@a_tuesday", TextBox3.Text);
            cmd.Parameters.AddWithValue("@a_wednesday", TextBox4.Text);
            cmd.Parameters.AddWithValue("@a_thursday", TextBox5.Text);
            cmd.Parameters.AddWithValue("@a_friday", TextBox6.Text);
            cmd.Parameters.AddWithValue("@a_saturday", TextBox7.Text);
            cmd.Parameters.AddWithValue("@b_time", TextBox8.Text);
            cmd.Parameters.AddWithValue("@b_monday", TextBox9.Text);
            cmd.Parameters.AddWithValue("@b_tuesday", TextBox10.Text);
            cmd.Parameters.AddWithValue("@b_wednesday", TextBox11.Text);
            cmd.Parameters.AddWithValue("@b_thursday", TextBox12.Text);
            cmd.Parameters.AddWithValue("@b_friday", TextBox13.Text);
            cmd.Parameters.AddWithValue("@b_saturday", TextBox14.Text);
            cmd.Parameters.AddWithValue("@c_time", TextBox15.Text);
            cmd.Parameters.AddWithValue("@c_monday", TextBox16.Text);
            cmd.Parameters.AddWithValue("@c_tuesday", TextBox17.Text);
            cmd.Parameters.AddWithValue("@c_wednesday", TextBox18.Text);
            cmd.Parameters.AddWithValue("@c_thursday", TextBox19.Text);
            cmd.Parameters.AddWithValue("@c_friday", TextBox20.Text);
            cmd.Parameters.AddWithValue("@c_saturday", TextBox21.Text);
            cmd.Parameters.AddWithValue("@d_time", TextBox22.Text);
            cmd.Parameters.AddWithValue("@d_monday", TextBox23.Text);
            cmd.Parameters.AddWithValue("@d_tuesday", TextBox24.Text);
            cmd.Parameters.AddWithValue("@d_wednesday", TextBox25.Text);
            cmd.Parameters.AddWithValue("@d_thursday", TextBox26.Text);
            cmd.Parameters.AddWithValue("@d_friday", TextBox27.Text);
            cmd.Parameters.AddWithValue("@d_saturday", TextBox28.Text);
            cmd.Parameters.AddWithValue("@e_time", TextBox29.Text);
            cmd.Parameters.AddWithValue("@e_monday", TextBox30.Text);
            cmd.Parameters.AddWithValue("@e_tuesday", TextBox31.Text);
            cmd.Parameters.AddWithValue("@e_wednesday", TextBox32.Text);
            cmd.Parameters.AddWithValue("@e_thursday", TextBox33.Text);
            cmd.Parameters.AddWithValue("@e_friday", TextBox34.Text);
            cmd.Parameters.AddWithValue("@e_saturday", TextBox35.Text);
            cmd.ExecuteNonQuery();
        }
        con.Close();
        Response.Redirect(Request.RawUrl);
    }
}