﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class admin_profile : System.Web.UI.Page
{


    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["student"] != null && Request.QueryString["student"] != "")
            {
                mycon();
                cmd = new MySqlCommand("select * from student_master where s_id=@id", con);
                cmd.Parameters.AddWithValue("@id", Request.QueryString["student"]);
                da = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rpt_pro.DataSource = ds;
                    rpt_pro.DataBind();
                }
                con.Close();
            }
        }
    }
}