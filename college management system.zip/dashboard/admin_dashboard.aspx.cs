﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;
public partial class dashboard_admin_dashboard : System.Web.UI.Page
{
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    int getStudent()
    {
        mycon();
        cmd = new MySqlCommand("select * from student_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _student_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _student_count;
    }

    int getTeacher()
    {
        mycon();
        cmd = new MySqlCommand("select * from teacher_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _teacher_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _teacher_count;
    }

    int getNotification()
    {
        mycon();
        cmd = new MySqlCommand("select * from announcement_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _notification_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _notification_count;
    }

    int getMessage()
    {
        mycon();
        cmd = new MySqlCommand("select * from message_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        int _message_count = ds.Tables[0].Rows.Count;
        con.Close();
        return _message_count;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mycon();
            cmd = new MySqlCommand("select * from announcement_master", con);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rpt_an.DataSource = ds;
                rpt_an.DataBind();
            }
            con.Close();

            count_student.InnerText = Convert.ToString(getStudent());
            count_teacher.InnerText = Convert.ToString(getTeacher());
            count_notification.InnerText = Convert.ToString(getNotification());
            count_message.InnerText = Convert.ToString(getMessage());

        }
    }
}