﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;


public partial class teacher_subject_info : System.Web.UI.Page
{
    static bool _isDataAvail = false;
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    DataSet getData()
    {
        mycon();
        cmd = new MySqlCommand("select * from subinfo_master where t_id=@id", con);
        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(Session["teacherId"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            subject_info_head.InnerText = Session["teacherBranch"].ToString();
            DataSet ds = getData();
            if (ds.Tables[0].Rows.Count > 0)
            {
                TextBox1.Text = ds.Tables[0].Rows[0]["subinfo_name"].ToString();
                TextBox2.Text = ds.Tables[0].Rows[0]["subinfo_code"].ToString();
                TextBox3.Text = ds.Tables[0].Rows[0]["subinfo_desc"].ToString();
                _isDataAvail = true;
            }
        }
    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        mycon();
        if(_isDataAvail == false)
        {
            cmd = new MySqlCommand("insert into subinfo_master values(NULL, @tid, @name, @code, @desc)", con);
            cmd.Parameters.AddWithValue("@tid", Convert.ToInt32(Session["teacherId"]));
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@code", TextBox2.Text);
            cmd.Parameters.AddWithValue("@desc", TextBox3.Text);
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Subject Information Added');window.location.href='teacher-subject-info.aspx'</script>");
        }
        else
        {
            cmd = new MySqlCommand("update subinfo_master set subinfo_name = @name, subinfo_code = @code, subinfo_desc = @desc where t_id = @tid", con);
            cmd.Parameters.AddWithValue("@tid", Convert.ToInt32(Session["teacherId"]));
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@code", TextBox2.Text);
            cmd.Parameters.AddWithValue("@desc", TextBox3.Text);
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Subject Information Updated');</script>");
        }
        con.Close();
    }
}