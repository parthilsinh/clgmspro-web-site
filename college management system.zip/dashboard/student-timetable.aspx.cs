﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class dashboard_student_timetable : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet _ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    void isDataAvail()
    {
        mycon();
        cmd = new MySqlCommand("select * from timetable_master where tt_branch=@branch", con);
        cmd.Parameters.AddWithValue("@branch", Convert.ToString(Session["teacherBranch"]));
        da = new MySqlDataAdapter(cmd);
        _ds = new DataSet();
        da.Fill(_ds);
        if (_ds.Tables[0].Rows.Count > 0)
        {
            // First lecture
            TextBox1.Text = _ds.Tables[0].Rows[0]["a_time"].ToString();
            TextBox2.Text = _ds.Tables[0].Rows[0]["a_monday"].ToString();
            TextBox3.Text = _ds.Tables[0].Rows[0]["a_tuesday"].ToString();
            TextBox4.Text = _ds.Tables[0].Rows[0]["a_wednesday"].ToString();
            TextBox5.Text = _ds.Tables[0].Rows[0]["a_thursday"].ToString();
            TextBox6.Text = _ds.Tables[0].Rows[0]["a_friday"].ToString();
            TextBox7.Text = _ds.Tables[0].Rows[0]["a_saturday"].ToString();
            // Second lecture
            TextBox8.Text = _ds.Tables[0].Rows[0]["b_time"].ToString();
            TextBox9.Text = _ds.Tables[0].Rows[0]["b_monday"].ToString();
            TextBox10.Text = _ds.Tables[0].Rows[0]["b_tuesday"].ToString();
            TextBox11.Text = _ds.Tables[0].Rows[0]["b_wednesday"].ToString();
            TextBox12.Text = _ds.Tables[0].Rows[0]["b_thursday"].ToString();
            TextBox13.Text = _ds.Tables[0].Rows[0]["b_friday"].ToString();
            TextBox14.Text = _ds.Tables[0].Rows[0]["b_saturday"].ToString();
            // Third lecture
            TextBox15.Text = _ds.Tables[0].Rows[0]["c_time"].ToString();
            TextBox16.Text = _ds.Tables[0].Rows[0]["c_monday"].ToString();
            TextBox17.Text = _ds.Tables[0].Rows[0]["c_tuesday"].ToString();
            TextBox18.Text = _ds.Tables[0].Rows[0]["c_wednesday"].ToString();
            TextBox19.Text = _ds.Tables[0].Rows[0]["c_thursday"].ToString();
            TextBox20.Text = _ds.Tables[0].Rows[0]["c_friday"].ToString();
            TextBox21.Text = _ds.Tables[0].Rows[0]["c_saturday"].ToString();
            // Fourth lecture
            TextBox22.Text = _ds.Tables[0].Rows[0]["d_time"].ToString();
            TextBox23.Text = _ds.Tables[0].Rows[0]["d_monday"].ToString();
            TextBox24.Text = _ds.Tables[0].Rows[0]["d_tuesday"].ToString();
            TextBox25.Text = _ds.Tables[0].Rows[0]["d_wednesday"].ToString();
            TextBox26.Text = _ds.Tables[0].Rows[0]["d_thursday"].ToString();
            TextBox27.Text = _ds.Tables[0].Rows[0]["d_friday"].ToString();
            TextBox28.Text = _ds.Tables[0].Rows[0]["d_saturday"].ToString();
            // Fifth lecture
            TextBox29.Text = _ds.Tables[0].Rows[0]["e_time"].ToString();
            TextBox30.Text = _ds.Tables[0].Rows[0]["e_monday"].ToString();
            TextBox31.Text = _ds.Tables[0].Rows[0]["e_tuesday"].ToString();
            TextBox32.Text = _ds.Tables[0].Rows[0]["e_wednesday"].ToString();
            TextBox33.Text = _ds.Tables[0].Rows[0]["e_thursday"].ToString();
            TextBox34.Text = _ds.Tables[0].Rows[0]["e_friday"].ToString();
            TextBox35.Text = _ds.Tables[0].Rows[0]["e_saturday"].ToString();
        }
        con.Close();
        //return ds;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            timetable_head.InnerText = "TIMETABLE FOR " + Convert.ToString(Session["teacherBranch"]).ToUpper();
            //DataSet _ds = isDataAvail();
            //if (_ds.Tables[0].Rows.Count > 0)
            //{

            //}
            isDataAvail();
        }
    }
}