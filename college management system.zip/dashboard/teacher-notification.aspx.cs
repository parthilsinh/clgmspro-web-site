﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class dashboard_teacher_notification : System.Web.UI.Page
{
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mycon();
            cmd = new MySqlCommand("select * from announcement_master", con);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rpt_an.DataSource = ds;
                rpt_an.DataBind();
            }
            con.Close();
        }
    }

    protected void btn_create_Click(object sender, EventArgs e)
    {
        mycon();
        cmd = new MySqlCommand("insert into announcement_master values(NULL, @for, @subject, @desc, @date)", con);
        cmd.Parameters.AddWithValue("@for", drop_for.SelectedValue);
        cmd.Parameters.AddWithValue("@subject", txt_sub.Text);
        cmd.Parameters.AddWithValue("@desc", txt_desc.Text);
        cmd.Parameters.AddWithValue("@date", System.DateTime.Now.ToString());
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect(Request.RawUrl);
    }


}