﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;
public partial class dashboard_teacher_registration : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }


    protected void Page_Load(object sender, EventArgs e)
    {
   
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        mycon();
        cmd = new MySqlCommand("select * from teacher_master where email=@email or username=@username", con);
        cmd.Parameters.AddWithValue("@email", TextBox4.Text);
        cmd.Parameters.AddWithValue("@username", TextBox14.Text);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            if (TextBox4.Text == ds.Tables[0].Rows[0]["email"].ToString())
            {
                Response.Write("<script>alert('Email already exist');</script>");
            }
            else if (TextBox14.Text == ds.Tables[0].Rows[0]["username"].ToString())
            {
                Response.Write("<script>alert('Username already exist');</script>");
            }
            else
            {
                Response.Write("<script>alert('Email and Username already exist');</script>");
            }
        }
        else
        {
            cmd = new MySqlCommand("insert into teacher_master values(NULL, @fname, @lname, @clgname, @email, @branch, @address, @city, @state, @aadhar, @dob, @mobile, @username, @password, @profile, @status, @reg_date)", con);
            cmd.Parameters.AddWithValue("@fname", TextBox1.Text);
            cmd.Parameters.AddWithValue("@lname", TextBox2.Text);
            cmd.Parameters.AddWithValue("@clgname", TextBox3.Text);
            cmd.Parameters.AddWithValue("@email", TextBox4.Text);
            cmd.Parameters.AddWithValue("@branch", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@address", TextBox8.Text);
            cmd.Parameters.AddWithValue("@city", TextBox9.Text);
            cmd.Parameters.AddWithValue("@state", TextBox10.Text);
            cmd.Parameters.AddWithValue("@aadhar", TextBox11.Text);
            cmd.Parameters.AddWithValue("@dob", TextBox12.Text);
            cmd.Parameters.AddWithValue("@mobile", TextBox13.Text);
            cmd.Parameters.AddWithValue("@username", TextBox14.Text);
            cmd.Parameters.AddWithValue("@password", TextBox15.Text);
            string _profile_photo = "";
            if (FileUpload1.HasFile)
            {
                ViewState["v2"] = System.IO.Path.GetExtension(FileUpload1.FileName);
                ViewState["v1"] = Guid.NewGuid().ToString() + ViewState["v2"];
                FileUpload1.SaveAs(Server.MapPath("~/dashboard/teacher_assets/" + ViewState["v1"]));
                _profile_photo = "~/dashboard/teacher_assets/" + ViewState["v1"];
            }
            cmd.Parameters.AddWithValue("@profile", _profile_photo);
            cmd.Parameters.AddWithValue("@status", 0);
            cmd.Parameters.AddWithValue("@reg_date", System.DateTime.Now.ToString());

            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Your registration is under varification'); window.location.href='../Default.aspx'</script>");

        }


        con.Close();
    }

}