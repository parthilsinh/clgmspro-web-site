﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class dashboard_teacher_top_students : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

  

    protected void Page_Load(object sender, EventArgs e)
    {
       
    }



    protected void btn_add_Click(object sender, EventArgs e)
    {
        mycon();
        cmd = new MySqlCommand("insert into topper_master values(NULL, @name, @branch, @enroll, @email, @year, @working)", con);
        //cmd = new MySqlCommand("update topper_master set top_name=@name, top_enroll=@enroll, top_branch=@branch, top_cgpa=@cgpa where top_rank=@rank", con);
        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@branch", DropDownList1.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@enroll", TextBox2.Text);
        cmd.Parameters.AddWithValue("@email", TextBox3.Text);
        cmd.Parameters.AddWithValue("@year", TextBox4.Text);
        cmd.Parameters.AddWithValue("@working", TextBox5.Text);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script>alert('Student record is added...');</script>");
    }
}