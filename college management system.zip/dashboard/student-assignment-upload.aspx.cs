﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
public partial class dashboard_student_assignment_upload : System.Web.UI.Page
{
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    void getAssign()
    {
        mycon();
        cmd = new MySqlCommand("select * from assignment_master am left join teacher_master tm on am.t_id=tm.t_id where am.asn_branch=@branch and (am.asn_sem=@sem and am.asn_div=@div)", con);
        cmd.Parameters.AddWithValue("@branch", Convert.ToString(Session["studentBranch"]));
        cmd.Parameters.AddWithValue("@sem", Convert.ToString(Session["studentSem"]));
        cmd.Parameters.AddWithValue("@div", Convert.ToString(Session["studentDiv"]));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rpt_assign.DataSource = ds;
            rpt_assign.DataBind();
        }

        con.Close();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getAssign();
        }
    }

    protected void rpt_assign_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        RepeaterItem item = e.Item;
        FileUpload FileUpload1 = (item.FindControl("FileUpload2") as FileUpload);
        string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
        int aid = Convert.ToInt32(commandArgs[0]);
        int tid = Convert.ToInt32(commandArgs[1]);
        int sid = Convert.ToInt32(Session["studentId"]);

        mycon();
        cmd = new MySqlCommand("insert into assignment_upload_master values(NULL, @aid, @tid, @sid, @doc, @date, @name, @enroll)", con);
        cmd.Parameters.AddWithValue("@aid", aid);
        cmd.Parameters.AddWithValue("@tid", tid);
        cmd.Parameters.AddWithValue("@sid", sid);
        string _assign = "";
        Boolean flag = true;
        if (FileUpload1.HasFile)
        {
            ViewState["v2"] = System.IO.Path.GetExtension(FileUpload1.FileName);
            ViewState["v1"] = Guid.NewGuid().ToString() + ViewState["v2"];
            FileUpload1.SaveAs(Server.MapPath("~/dashboard/student_assignment/" + ViewState["v1"]));
            _assign = "~/dashboard/student_assignment/" + ViewState["v1"];   
        }
        else
        {
            flag = false;
        }

        cmd.Parameters.AddWithValue("@doc", _assign);
        cmd.Parameters.AddWithValue("@date", System.DateTime.Now.ToString());
        cmd.Parameters.AddWithValue("@name", Session["studentName"].ToString());
        cmd.Parameters.AddWithValue("@enroll", Session["studentEnroll"].ToString());
        
        if(flag == true)
        {
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect(Request.RawUrl);
        }
        else
        {
            Response.Write("<script>alert('Please Upload Assignment First')</script>");
        }
        

    }

    protected void rpt_assign_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        RepeaterItem item = e.Item;
        FileUpload FileUpload1 = (item.FindControl("FileUpload2") as FileUpload);
        HyperLink HyperLink2 = (item.FindControl("HyperLink2") as HyperLink);
        Button B1 = (item.FindControl("btn_submit") as Button);
        HiddenField hf1 = (item.FindControl("HiddenField1") as HiddenField);
        mycon();
        cmd = new MySqlCommand("select * from assignment_upload_master where ans_id=@aid", con);
        cmd.Parameters.AddWithValue("@aid", Convert.ToInt32(hf1.Value));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            FileUpload1.Visible = false;
            HyperLink2.Visible = true;
            HyperLink2.NavigateUrl = ds.Tables[0].Rows[0]["au_doc"].ToString();
            B1.Enabled = false;
            B1.Text = "Submitted";
        }
        con.Close();

    }
}