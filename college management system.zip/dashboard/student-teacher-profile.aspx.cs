﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class dashboard_student_teacher_profile : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mycon();
            cmd = new MySqlCommand("select *, CONCAT(f_name, ' ', l_name) AS fullname from teacher_master", con);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);

            DropDownList1.DataTextField = ds.Tables[0].Columns["fullname"].ToString();
            DropDownList1.DataValueField = ds.Tables[0].Columns["t_id"].ToString();
            DropDownList1.DataSource = ds;
            DropDownList1.DataBind();
            DropDownList1.Items.Add("--select teacher--");
            //DropDownList1.DataValueField = "--select teacher--";
            DropDownList1.SelectedValue = "--select teacher--";
            con.Close();
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        mycon();
        if (DropDownList1.SelectedValue != "--select teacher--")
        {
            cmd = new MySqlCommand("select * from teacher_master tm left join subinfo_master sm on tm.t_id=sm.t_id where tm.t_id=@id and branch=@branch", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(DropDownList1.SelectedValue));
            cmd.Parameters.AddWithValue("@branch", Convert.ToString(Session["studentBranch"]));
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rpt_pro.DataSource = ds;
                rpt_pro.DataBind();
            }
        }
        con.Close();
    }
}