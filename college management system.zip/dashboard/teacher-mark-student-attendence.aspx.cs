﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;

public partial class dashboard_teacher_mark_student_attendence : System.Web.UI.Page
{
    
    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
     
    }

    protected void btn_select_Click(object sender, EventArgs e)
    {
        mycon();
        cmd = new MySqlCommand("select * from student_master where branch=@branch and (sem=@sem and division=@division)", con);
        cmd.Parameters.AddWithValue("@branch", drop_branch.SelectedValue);
        cmd.Parameters.AddWithValue("@sem", drop_sem.SelectedValue);
        cmd.Parameters.AddWithValue("@division", drop_div.SelectedValue);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rpt_att.DataSource = ds;
            rpt_att.DataBind();
        }
        else
        {
            //Response.Write(Request.RawUrl);
            rpt_att.DataSource = ds;
            rpt_att.DataBind();
        }
        con.Close();
    }

    protected void rpt_att_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        RepeaterItem item = e.Item;
        DropDownList drop1 = (item.FindControl("drop_att") as DropDownList);
        HiddenField hf1 = (item.FindControl("HiddenField1") as HiddenField);
        Button b1 = (item.FindControl("btn_att_save") as Button);
        mycon();
        cmd = new MySqlCommand("select * from attendence_master where s_id=@sid and att_date=@date", con);
        cmd.Parameters.AddWithValue("@sid", Convert.ToInt32(hf1.Value));
        cmd.Parameters.AddWithValue("@date", System.DateTime.Today.ToString("dd-MM-yyyy"));
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            b1.Text = "saved";
            b1.Enabled = false;
            drop1.SelectedValue = ds.Tables[0].Rows[0]["att_status"].ToString();
            drop1.Enabled = false;
        }
        else
        {
            b1.Text = "save";
            b1.Enabled = true;
        }

        con.Close();
    }

    protected void rpt_att_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        RepeaterItem item = e.Item;
        DropDownList drop1 = (item.FindControl("drop_att") as DropDownList);
        Button b1 = (item.FindControl("btn_att_save") as Button);

        int _student_id = Convert.ToInt32(e.CommandArgument);
        mycon();
        cmd = new MySqlCommand("insert into attendence_master values(NULL, @sid, @status, @date)", con);
        cmd.Parameters.AddWithValue("@sid", _student_id);
        cmd.Parameters.AddWithValue("@status", drop1.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@date", System.DateTime.Today.ToString("dd-MM-yyyy"));
        cmd.ExecuteNonQuery();
        con.Close();
        b1.Text = "saved";
        b1.Enabled = false;
        drop1.Enabled = false;

    }

    protected void btn_save_Click(object sender, EventArgs e)
    {

        Response.Write(System.DateTime.Today.ToString("dd-MM-yyyy"));
      
    }
}