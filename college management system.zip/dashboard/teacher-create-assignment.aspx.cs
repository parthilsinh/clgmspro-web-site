﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class dashboard_teacher_create_assignment : System.Web.UI.Page
{

    MySqlConnection con;
    MySqlCommand cmd;
    MySqlDataAdapter da;
    DataSet ds;
    void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_create_Click(object sender, EventArgs e)
    {
        mycon();
        cmd = new MySqlCommand("insert into assignment_master values(NULL, @branch, @sem, @div, @start, @due, @remark, @doc, @tid)", con);
        cmd.Parameters.AddWithValue("@branch",drop_branch.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@sem",drop_sem.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@div", drop_div.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@start",System.DateTime.Now.ToString("yyyy-MM-dd"));
        cmd.Parameters.AddWithValue("@due",txt_due.Text);
        cmd.Parameters.AddWithValue("@remark",txt_remark.Text);
        string _assign = "";
        if (FileUpload1.HasFile)
        {
            ViewState["v2"] = System.IO.Path.GetExtension(FileUpload1.FileName);
            ViewState["v1"] = Guid.NewGuid().ToString() + ViewState["v2"];
            FileUpload1.SaveAs(Server.MapPath("~/dashboard/teacher_assignment/" + ViewState["v1"]));
            _assign = "~/dashboard/teacher_assignment/" + ViewState["v1"];
        }
        cmd.Parameters.AddWithValue("@doc", _assign);
        cmd.Parameters.AddWithValue("@tid",Convert.ToInt32(Session["teacherId"]));
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Assignment Created');</script>");
        con.Close();
    }
}